This my 1-week calendar.
I'm sorry, I don't now the latest javascript librairy, so I tried to do it with old javascript.
Unfortunately, this version doesn't allow to change week for many reasons.
So I put this version in GitHub, to give you something before the weekend.

And even if it's too late, I'll try to do a new version this week-end with a tutorial on Angular, that will help me for later.   